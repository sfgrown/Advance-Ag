import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4173;
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const dataPath = (name) => path.join(__dirname, 'data', name);
const read = (name) => JSON.parse(fs.readFileSync(dataPath(name), 'utf8'));
const write = (name, value) => fs.writeFileSync(dataPath(name), JSON.stringify(value, null, 2));

app.get('/api/health', (_, res) => res.json({ ok: true, service: 'advance-ag-group' }));
app.get('/api/news', (_, res) => res.json(read('news.json')));
app.get('/api/news/:slug', (req, res) => {
  const item = read('news.json').find((x) => x.slug === req.params.slug);
  item ? res.json(item) : res.status(404).json({ error: 'Not found' });
});
app.get('/api/portfolio', (_, res) => res.json(read('portfolio.json')));
app.post('/api/inquiries', (req, res) => {
  const { name, email, message, organization = '', type = '', language = 'en' } = req.body || {};
  if (!name || !email || !message) return res.status(400).json({ error: 'Required fields missing' });
  const items = read('inquiries.json');
  items.push({ id: crypto.randomUUID(), name, email, organization, type, message, language, receivedAt: new Date().toISOString(), status: 'new' });
  write('inquiries.json', items);
  res.status(201).json({ ok: true });
});

const dist = path.join(__dirname, '../client/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist, { maxAge: '1h' }));
  app.get('*', (_, res) => res.sendFile(path.join(dist, 'index.html')));
} else {
  app.get('/', (_, res) => res.send('Advance Ag API running. Start the Vite client for the website.'));
}

app.listen(PORT, () => console.log(`Advance Ag Group running on http://localhost:${PORT}`));

import { supabase } from './supabase';

const base = import.meta.env.VITE_API_BASE || '/api';

async function fetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

export async function getNews(locale = 'en') {
  if (supabase) {
    const { data, error } = await supabase.from('news').select('*').eq('published', true).order('published_at', { ascending: false });
    if (!error) return data.map(x => normalizeNews(x, locale));
  }
  return fetchJSON(`${base}/news`);
}

export async function getNewsItem(slug, locale = 'en') {
  if (supabase) {
    const { data, error } = await supabase.from('news').select('*').eq('slug', slug).eq('published', true).maybeSingle();
    if (!error && data) return normalizeNews(data, locale);
  }
  return fetchJSON(`${base}/news/${slug}`);
}

export async function getPortfolio(locale = 'en') {
  if (supabase) {
    const { data, error } = await supabase.from('portfolio').select('*').eq('published', true).order('sort_order');
    if (!error) return data;
  }
  return fetchJSON(`${base}/portfolio`);
}

export async function submitInquiry(payload) {
  if (supabase) {
    const { error } = await supabase.from('inquiries').insert(payload);
    if (!error) return { ok: true };
  }
  return fetchJSON(`${base}/inquiries`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
}

function normalizeNews(x, locale = 'en') {
  return {
    ...x,
    date: x.date || (x.published_at ? new Date(x.published_at).toLocaleDateString(locale === 'pcm' ? 'en-NG' : locale, { year: 'numeric', month: 'long', day: 'numeric' }) : ''),
    body: Array.isArray(x.body) ? x.body : (x.body ? String(x.body).split('\n\n') : [])
  };
}

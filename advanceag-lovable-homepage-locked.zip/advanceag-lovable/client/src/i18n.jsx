import React, {createContext, useContext, useEffect, useMemo, useState} from 'react';
import {localeCopy, languageOptions} from './locales';

const I18nContext = createContext(null);
const STORAGE_KEY = 'advanceag-language';

function detectLanguage(){
  const stored = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
  if (stored && localeCopy[stored]) return stored;
  const raw = typeof navigator !== 'undefined' ? (navigator.languages?.[0] || navigator.language || 'en') : 'en';
  const code = raw.toLowerCase();
  if (code.startsWith('es')) return 'es-MX';
  if (code.startsWith('pt')) return 'pt';
  if (code.startsWith('nl')) return 'nl';
  if (code.startsWith('de')) return 'de';
  if (code.startsWith('pl')) return 'pl';
  if (code.startsWith('uk')) return 'uk';
  if (code.startsWith('ru')) return 'ru';
  if (code.startsWith('fr')) return 'fr';
  if (code.startsWith('ar')) return 'ar';
  if (code.startsWith('sw')) return 'sw';
  return 'en';
}

function deepGet(obj,path){return path.split('.').reduce((acc,k)=>acc?.[k],obj)}

export function I18nProvider({children}){
  const [language,setLanguageState] = useState(detectLanguage);
  const setLanguage=(next)=>{if(localeCopy[next]) setLanguageState(next)};
  useEffect(()=>{
    localStorage.setItem(STORAGE_KEY, language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  },[language]);
  const value=useMemo(()=>({
    language,
    languages: languageOptions,
    setLanguage,
    t:(key)=>deepGet(localeCopy[language],key) ?? deepGet(localeCopy.en,key) ?? key,
    localize:(record)=>{
      if(!record) return record;
      const localized = record.translations?.[language] || record.translations?.[language.split('-')[0]];
      return localized ? {...record,...localized} : record;
    }
  }),[language]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n(){return useContext(I18nContext)}

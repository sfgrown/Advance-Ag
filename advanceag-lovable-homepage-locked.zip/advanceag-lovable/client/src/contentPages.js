export const approachPages = {
  'build-operate': {
    eyebrow: 'BUILD & OPERATE',
    title: 'Build technology around the way growers actually work.',
    lede: 'Advance Ag is the AgTech operating business within Advance Ag Group. Its role is to make agricultural technology more connected, practical, and useful without asking growers to rebuild their entire operation around one vendor.',
    image: '/assets/portfolio/agtech.jpg',
    sections: [
      {
        heading: 'Start with the operation, not the device.',
        paragraphs: [
          'Advance Ag began with a simple observation: farms increasingly rely on technology, but the technology does not always work together. Equipment, sensors, weather systems, irrigation controls, cameras, applications, and data can sit beside one another while still behaving like separate islands.',
          'The goal of Advance Ag is not to manufacture every tool a grower may need. It is to create a more useful operating layer across third-party technologies so growers can see, understand, and manage more of their operation from one environment. The original idea was often described as an “Alexa for smart farming” — not because farming should be automated for its own sake, but because the technology around a farm should be easier to use together.'
        ]
      },
      {
        heading: 'Interoperability is a farmer issue.',
        paragraphs: [
          'Closed technology ecosystems can force growers into expensive replacement cycles or make them choose between systems that each solve only part of the problem. A farmer-centered architecture works differently: it begins with the equipment and tools already in the field, then looks for ways to connect them, add capability over time, and reduce unnecessary friction.',
          'That means the platform is designed around practical workflows — monitoring conditions, coordinating equipment, bringing data together, and enabling remote actions where supported — while keeping the grower in control of the operation.'
        ]
      },
      {
        heading: 'Technology is the tool. Better farming is the objective.',
        paragraphs: [
          'The value of connected AgTech is not the dashboard itself. It is the ability to make better-informed decisions about water, labor, timing, equipment, crop conditions, and other resources. The technology side of Advance Ag remains foundational to the Group because it keeps the broader strategy anchored in the realities of production.',
          'As Advance Ag Group expands into investment and systems work, Advance Ag continues to represent the operating question at the center of the company: what can we build that makes agriculture work better for the people doing it?'
        ]
      }
    ],
    ctaTitle: 'Explore the AgTech business',
    ctaText: 'See how Advance Ag connects agricultural technologies into a more useful operating environment.',
    ctaLabel: 'Visit Advance Ag',
    ctaTo: '/advance-ag'
  },
  'acquire-invest': {
    eyebrow: 'ACQUIRE & INVEST',
    title: 'Invest where agriculture can work better.',
    lede: 'Advance Ag Group acquires and invests in agricultural technology, science, intellectual property, businesses, and practical innovations that can strengthen production and the systems surrounding it.',
    image: '/assets/portfolio/innovation.jpg',
    sections: [
      {
        heading: 'The problem comes before the asset class.',
        paragraphs: [
          'Agricultural innovation does not arrive in one form. Sometimes the answer is software. Sometimes it is better equipment, a new material, improved soil or water science, a biological input, a process, a piece of intellectual property, or an operating business with a useful solution already in the market.',
          'Advance Ag Group therefore does not define innovation narrowly. The investment lens starts with a practical question: does this help solve a meaningful agricultural problem, and can it create durable value for growers or the systems they depend on?'
        ]
      },
      {
        heading: 'Capital should help good solutions move.',
        paragraphs: [
          'The Group can support innovation through acquisition, investment, strategic partnership, commercialization, or operating support. The objective is not to collect technologies for the sake of having a portfolio. It is to help useful ideas move from possibility to practical application while keeping the agricultural problem in view.',
          'This approach also creates room for innovation that may be overlooked by conventional technology categories — including agricultural science, resource management, production systems, post-harvest infrastructure, and solutions that strengthen the path from farm to market.'
        ]
      },
      {
        heading: 'A broader view of return.',
        paragraphs: [
          'Agriculture is an economic system, but it is also a living system. Strong investments should therefore be capable of improving productivity, resilience, resource efficiency, market access, or operating stability without treating the grower as an afterthought.',
          'Advance Ag Group looks for investments that can stand on their own merits while contributing to a stronger agricultural ecosystem over time.'
        ]
      }
    ],
    ctaTitle: 'See the investment lens',
    ctaText: 'Learn more about the categories and problems Advance Ag Group considers across agriculture.',
    ctaLabel: 'Explore Investments',
    ctaTo: '/investments'
  },
  'partner-advance': {
    eyebrow: 'PARTNER & ADVANCE',
    title: 'Strengthen the systems shaped around growers.',
    lede: 'Agriculture does not stop at the farm gate. Advance Ag Group works across the relationships, infrastructure, markets, institutions, and supply chains that determine whether good production can become a healthy agricultural economy.',
    image: '/assets/portfolio/partnerships.jpg',
    sections: [
      {
        heading: 'The farmer sits inside a larger architecture.',
        paragraphs: [
          'A grower can make every right decision in the field and still be constrained by financing, input costs, water access, infrastructure, market concentration, logistics, or the absence of a reliable buyer. Those are not side issues. They are part of the operating environment of agriculture.',
          'Advance Ag Group approaches agrifood systems from that reality. The work begins with the people producing food and asks what systems around them need to function better.'
        ]
      },
      {
        heading: 'Partnership is how system gaps get closed.',
        paragraphs: [
          'Many agricultural challenges sit between institutions rather than inside one organization. A supply-chain gap may require growers, buyers, logistics partners, local government, universities, technology providers, and capital to work in concert. A market-access problem may require a completely different set of relationships.',
          'The Group’s role is often connective: identify the real constraint, bring the relevant parties together, and shape a practical path that each participant can understand and act on.'
        ]
      },
      {
        heading: 'Local knowledge should remain visible.',
        paragraphs: [
          'Agricultural systems are shaped by place. Climate, culture, crop, land, labor, infrastructure, and markets vary widely, so a model that succeeds in one region cannot simply be copied into another without adaptation.',
          'The aim is not to impose a universal template. It is to build from local realities, preserve what already works, and connect the resources that can help growers and communities become more resilient.'
        ]
      }
    ],
    ctaTitle: 'Bring us the problem',
    ctaText: 'We work with growers, innovators, institutions, investors, agribusinesses, and public-sector partners.',
    ctaLabel: 'Partner With Us',
    ctaTo: '/partner'
  }
};

export const insightArticles = {
  'agtech-solutions': {
    category: 'AgTech Solutions',
    title: 'AgTech should fit the farm — not force the farm to fit the technology.',
    dek: 'The next useful step in smart farming is not simply more devices. It is better connection between the tools growers already use and the decisions they need to make.',
    image: '/assets/portfolio/agtech.jpg',
    readTime: '5 min read',
    sections: [
      { heading: 'A farm can be connected and still be fragmented.', paragraphs: [
        'Agriculture has no shortage of technology. A modern operation may use tractors from one manufacturer, irrigation controls from another, weather stations, soil sensors, cameras, drones, satellite information, harvest equipment, spreadsheets, and multiple software applications. Each system can be useful while still creating another place the grower has to look.',
        'That fragmentation is more than an inconvenience. It can make data harder to compare, increase training and switching costs, and create a technology environment that grows more complicated as the farm becomes more sophisticated.'
      ]},
      { heading: 'The architecture matters.', paragraphs: [
        'Advance Ag was built around a different idea: treat the farm as the operating system and technology as a set of tools that should be capable of working around it. The platform is designed to connect third-party equipment, sensors, applications, and data so growers can add capability without being forced into a single closed ecosystem.',
        'The “Alexa for smart farming” analogy helped explain the concept early on. The deeper idea is interoperability. A grower should be able to understand what is happening across an operation, bring useful information together, and take supported actions without having to rebuild the farm around the software.'
      ]},
      { heading: 'Connected data is only useful when it changes a decision.', paragraphs: [
        'The purpose of agricultural data is not to create a prettier dashboard. It is to help someone decide when to irrigate, where to inspect, how equipment is performing, whether a field condition is changing, or which resource needs attention first.',
        'That is why the company’s technology philosophy remains farmer-centered: start with the operational question, then determine which data and tools are actually useful. More information is not automatically better information.'
      ]},
      { heading: 'AgTech is part of a larger system.', paragraphs: [
        'Advance Ag Group eventually expanded beyond technology because field experience made one thing clear: a highly connected farm can still be held back by weak financing, expensive inputs, infrastructure gaps, limited market access, or an unreliable supply chain.',
        'The AgTech business remains important precisely because it keeps the Group close to the farm. Technology can improve decisions and operations. The broader Group exists to work on the other systems that determine whether those gains can translate into stronger agricultural businesses and communities.'
      ]}
    ]
  },
  'agricultural-innovation': {
    category: 'Agricultural Innovation',
    title: 'Innovation in agriculture is bigger than software.',
    dek: 'Useful agricultural innovation can emerge from technology, biology, materials, equipment, science, process design, or a better way to connect an existing solution to the people who need it.',
    image: '/assets/portfolio/innovation.jpg',
    readTime: '5 min read',
    sections: [
      { heading: 'Agriculture rewards practical innovation.', paragraphs: [
        'The most valuable agricultural innovations are not always the most visible. A better soil input, a new irrigation method, a production tool, an improved seed trait, a piece of equipment, or a change in post-harvest handling can matter just as much as a new digital platform.',
        'Advance Ag Group uses a broad definition because agriculture itself is broad. Production depends on biology, engineering, chemistry, weather, water, labor, finance, logistics, and markets. Innovation can enter at any of those points.'
      ]},
      { heading: 'Start with the constraint.', paragraphs: [
        'The Group’s investment and acquisition lens begins with the agricultural constraint rather than a predetermined technology category. What is preventing a grower, agricultural business, or local food economy from working better? Is the problem yield, resource efficiency, labor, crop loss, market access, cost, infrastructure, or resilience?',
        'Once the constraint is understood, the right solution may be developed internally, acquired, licensed, invested in, or advanced through partnership.'
      ]},
      { heading: 'Innovation should remain accessible.', paragraphs: [
        'A technology can be technically impressive and still fail agriculture if the business model prices out the people who need it. Access, usability, compatibility, maintenance, and the economics of adoption matter alongside performance.',
        'That is particularly important for small and medium-sized growers, who often have fewer resources available for experimentation even though they may benefit greatly from better tools and science.'
      ]},
      { heading: 'The goal is a stronger agricultural system.', paragraphs: [
        'Advance Ag Group is interested in innovation that can improve how agriculture produces, uses resources, moves products, or reaches markets. The common thread is not novelty. It is practical value.',
        'That keeps the innovation strategy grounded: support what can make agriculture work better, and evaluate success by what changes for the grower and the system around them.'
      ]}
    ]
  },
  'resource-water-systems': {
    category: 'Resource & Water Systems',
    title: 'Water is not a feature of agriculture. It is part of its operating architecture.',
    dek: 'Resource efficiency becomes meaningful when better measurement, management, infrastructure, and local knowledge work together.',
    image: '/assets/portfolio/water.jpg',
    readTime: '5 min read',
    sections: [
      { heading: 'Every farm is a resource-management system.', paragraphs: [
        'Water, soil, nutrients, energy, land, and labor all interact. A change in one can affect yield, cost, crop quality, timing, and long-term viability. Managing those resources well requires more than a single sensor or conservation target.',
        'It requires understanding how resources move through the operation and where better information, infrastructure, or practice can create the greatest benefit.'
      ]},
      { heading: 'Measurement creates options.', paragraphs: [
        'AgTech can help growers understand conditions that were once difficult or slow to see. Weather data, soil information, irrigation monitoring, imaging, and connected equipment can make resource use more visible and allow decisions to be made with greater precision.',
        'The useful outcome is not measurement for its own sake. It is the ability to reduce unnecessary use, respond earlier to changing conditions, and protect productivity while managing critical resources more carefully.'
      ]},
      { heading: 'Infrastructure still matters.', paragraphs: [
        'Better information cannot compensate for every physical constraint. Water systems, storage, distribution infrastructure, drainage, energy availability, and regional policy can determine what is possible on the farm long before a digital tool enters the picture.',
        'That is why Advance Ag Group treats resource and water systems as both an innovation opportunity and a systems question. Technology can improve management, while investment and partnership may be needed to address the larger infrastructure surrounding it.'
      ]},
      { heading: 'The solution has to fit place.', paragraphs: [
        'Water challenges differ by crop, climate, watershed, regulation, infrastructure, and local practice. A system that works in one region may be inappropriate in another.',
        'A farmer-shaped approach begins with those local realities and builds outward — combining science, technology, infrastructure, and experience in a way that respects the operating environment.'
      ]}
    ]
  },
  'supply-chain-infrastructure': {
    category: 'Supply Chain & Infrastructure',
    title: 'A strong harvest is only the beginning.',
    dek: 'Agriculture creates value in the field, but that value can be lost when storage, processing, logistics, buyers, or market infrastructure fail to keep pace.',
    image: '/assets/portfolio/supply-chain.jpg',
    readTime: '6 min read',
    sections: [
      { heading: 'The farm gate is not the end of the system.', paragraphs: [
        'A grower can produce an excellent crop and still struggle to turn that production into a stable business. Products have to be stored, processed where necessary, transported, sold, and paid for. Timing matters. Cold chain may matter. Buyer concentration may matter. Distance to market may matter.',
        'Those conditions shape what can be grown, what can be sold, and whether the economics work.'
      ]},
      { heading: 'Supply-chain problems often look like farm problems.', paragraphs: [
        'When a farmer cannot find a reliable market, excess product can look like overproduction. When transport is too expensive, a competitive crop can look unprofitable. When infrastructure is absent, a high-value product can lose value before it reaches a buyer.',
        'A systems approach separates the production issue from the surrounding constraint so the right problem gets solved.'
      ]},
      { heading: 'Local and regional systems can create resilience.', paragraphs: [
        'Long supply chains have a role in the food economy, but they should not be the only pathway available. Stronger local and regional market connections can reduce distance, create additional outlets for growers, preserve more value within agricultural communities, and give institutions new sourcing options.',
        'That can involve physical infrastructure, shared logistics, food hubs, institutional purchasing, data, market coordination, or simply better connections between producers and buyers.'
      ]},
      { heading: 'Infrastructure is an economic tool.', paragraphs: [
        'Roads, storage, processing, distribution, water, energy, and market facilities are not background conditions. They shape the economics of agriculture. The right infrastructure can expand what a region is capable of producing and selling.',
        'Advance Ag Group looks at supply chains and infrastructure through that lens: not as a separate sector from farming, but as part of the architecture that determines whether growers can participate in healthy markets.'
      ]}
    ]
  },
  'strategic-partnerships': {
    category: 'Strategic Partnerships',
    title: 'The hardest agricultural problems rarely belong to one organization.',
    dek: 'Partnership becomes strategic when each participant brings a piece of the solution and the work is organized around a shared agricultural problem rather than a ceremonial relationship.',
    image: '/assets/portfolio/partnerships.jpg',
    readTime: '5 min read',
    sections: [
      { heading: 'Agriculture is already collaborative.', paragraphs: [
        'Growers depend on networks of suppliers, buyers, lenders, researchers, regulators, equipment providers, service businesses, and communities. The challenge is not convincing agriculture to collaborate. The challenge is making those relationships work toward the same practical outcome.',
        'Advance Ag Group approaches partnership as a form of systems design: identify the constraint, understand who controls which part of it, and bring together the participants who can actually change the outcome.'
      ]},
      { heading: 'Different partners solve different parts of the problem.', paragraphs: [
        'A university may contribute research. A technology company may contribute a tool. A grower contributes field knowledge and a real operating environment. A government may control policy or infrastructure. An investor may provide capital. A buyer may create the market pathway that makes the entire effort economically viable.',
        'The value comes from the combination, not from treating every partner as interchangeable.'
      ]},
      { heading: 'Good partnership protects the farmer’s place in the system.', paragraphs: [
        'Agricultural partnerships can fail when the people producing the food are included only at the end. A farmer-centered approach brings growers into the design of the work early enough for their constraints, economics, and practical knowledge to shape the solution.',
        'That reduces the risk of building programs that look strong on paper but are difficult to use, maintain, afford, or sustain in the field.'
      ]},
      { heading: 'Partnership should lead to work.', paragraphs: [
        'Advance Ag Group is interested in partnerships that create a clear path to action: testing, investment, acquisition, market access, infrastructure, research, commercialization, or system development.',
        'The point is not simply to connect organizations. It is to connect the right capabilities around a problem worth solving.'
      ]}
    ]
  }
};

# Lovable implementation prompt — Advance Ag Group

Import this codebase and treat the supplied implementation as the design source of truth. Do not replace it with a generic Lovable/SaaS template. Preserve the visual identity, copy hierarchy, section order, typography strategy, dark forest green / cream / olive palette, leaf macro imagery, current Advance Ag Group logo, spacing, and farmer-shaped systems language.

The corporate architecture is non-negotiable: **Advance Ag Group is the parent company; Advance Ag is the AgTech business inside the Group.** The Group develops, acquires, partners with, and invests in agricultural technology and innovation. Investment is one mechanism, not the entire identity of the Group.

## UX and visual requirements
- Preserve the approved homepage composition and premium editorial/agricultural feel.
- Maintain Barlow Condensed for strong display headlines, Libre Baskerville for editorial/institutional moments, and Inter for UI/body text.
- Keep motion restrained and purposeful. Use subtle reveal, hover, active-navigation, focus, loading, and transition states already represented in the code.
- No neon gradients, glassmorphism, sci-fi interfaces, generic dashboards, startup illustrations, or stock-tech visuals.
- Agriculture must feel real and grounded; technology should appear as part of the system, not as the hero.
- Mobile must retain the same hierarchy, not simply stack everything without rhythm.

## Messaging principles
The site should sound like it was shaped by people who understand farms and the systems around them. Use practical language. Start with growers and real operating problems, then explain the systems supporting them: technology, capital, inputs, water, infrastructure, supply chains, markets, institutions, and innovation.

Do not invent metrics, portfolio companies, named integrations, investment amounts, customers, or impact claims.

## Backend
Use Supabase as the production backend. Run `supabase/schema.sql` and connect the client using `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.

Required data functionality:
1. Public published-news feed and individual article pages.
2. Public published portfolio/selected-work feed.
3. Partnership inquiry form stored in `inquiries`.
4. Prepare for a future authenticated admin dashboard, but do not expose public write access to news or portfolio.

## Pages
- `/` Home
- `/group`
- `/advance-ag`
- `/investments`
- `/portfolio`
- `/about`
- `/news`
- `/news/:slug`
- `/partner`

Do not collapse these into a one-page website.

## Final polish to preserve
The home page should feel sophisticated enough for institutional investors, ministries of agriculture, universities, innovators, and acquisition targets, while remaining understandable and credible to growers. The key emotional signal is: **by farmers, for farmers — with the systems behind agriculture shaped around them.**

## Multilingual / localization requirements — non-negotiable
The website includes a polished language selector in the primary menu. Preserve it and keep the selected locale across routes and sessions.

Supported languages:
- English (`en`)
- Mexican Spanish / Español (México) (`es-MX`)
- Portuguese / Português (`pt`)
- Dutch / Nederlands (`nl`)
- German / Deutsch (`de`)
- Polish / Polski (`pl`)
- Ukrainian / Українська (`uk`)
- Russian / Русский (`ru`)
- French / Français (`fr`)
- Nigerian Pidgin (`pcm`)
- Arabic / العربية (`ar`)
- Swahili / Kiswahili (`sw`)

Implementation rules:
1. Do not use flags as language icons; languages cross national borders. Use the globe selector already implemented.
2. Browser language may set the first visit default; after a visitor chooses a language, persist it in localStorage.
3. Arabic must switch the document to `dir="rtl"` and preserve the same premium hierarchy and spacing rather than simply mirroring poorly.
4. All static interface and page copy must use the locale catalog in `client/src/locales.js` with English as fallback.
5. News and portfolio records use the Supabase `translations` JSONB field. Resolve the selected locale first, then fall back to English.
6. Date formatting must use the active locale.
7. Partnership inquiries must store the visitor's selected `language` so follow-up communication can match it.
8. When an editor publishes a news or portfolio item, provide locale fields for every supported language or clearly mark untranslated locales in the future admin dashboard. Never silently fabricate a translation in the CMS.
9. Preserve brand names such as Advance Ag and Advance Ag Group rather than translating them.
10. SEO should eventually add locale-specific `hreflang`, localized metadata, and translated Open Graph descriptions when production domain routing is finalized.

## REQUIRED DEEP-LINK CONTENT ARCHITECTURE
Do not flatten homepage calls-to-action into anchors or generic pages. Preserve these exact intent-based routes and make them fully clickable with hover/focus states:
- Explore the Group → `/group`
- Partner With Us → `/partner`
- Read Our Story → `/our-story`
- View Our Portfolio → `/portfolio`
- Build & Operate → `/approach/build-operate`
- Acquire & Invest → `/approach/acquire-invest`
- Partner & Advance → `/approach/partner-advance`
- AgTech Solutions card/image → `/insights/agtech-solutions`
- Agricultural Innovation card/image → `/insights/agricultural-innovation`
- Resource & Water Systems card/image → `/insights/resource-water-systems`
- Supply Chain & Infrastructure card/image → `/insights/supply-chain-infrastructure`
- Strategic Partnerships card/image → `/insights/strategic-partnerships`

The five Selected Work image cards must behave as editorial article cards: the full card and its image should be clickable, keyboard accessible, and show a restrained hover affordance. Preserve the long-form editorial pages in `client/src/contentPages.js`; do not replace them with generic marketing filler. The copy is intentionally grounded in the history and operating model of Advance Ag Group and avoids invented portfolio claims.

The site already has a multilingual selector. Keep the current translations and language persistence. For the new long-form editorial content, use the English copy in `contentPages.js` as the canonical source and add high-quality localized variants for every currently supported locale while preserving English fallback. Do not use a third-party translation widget overlay.

## HOMEPAGE VISUAL LOCK — DO NOT REDESIGN
The attached approved homepage screenshot is the immutable visual reference for the homepage. Do not add sections, remove sections, change typography, alter layout, rewrite homepage copy, add visible labels to the Selected Work cards, or redesign the homepage in any way. The homepage changes in this build are interaction-only: existing buttons, arrow controls, images, and cards route to detailed internal pages. Preserve the exact visual composition while making those existing elements clickable and accessible.

Required homepage destinations:
- Explore the Group → `/group`
- Partner With Us → `/partner`
- Read Our Story → `/our-story`
- View Our Portfolio → `/portfolio`
- Build & Operate arrow → `/approach/build-operate`
- Acquire & Invest arrow → `/approach/acquire-invest`
- Partner & Advance arrow → `/approach/partner-advance`
- AgTech Solutions card/image → `/insights/agtech-solutions`
- Agricultural Innovation card/image → `/insights/agricultural-innovation`
- Resource & Water Systems card/image → `/insights/resource-water-systems`
- Supply Chain & Infrastructure card/image → `/insights/supply-chain-infrastructure`
- Strategic Partnerships card/image → `/insights/strategic-partnerships`

The detailed destination pages may be expansive and editorial. The homepage may not be altered to preview that additional detail.

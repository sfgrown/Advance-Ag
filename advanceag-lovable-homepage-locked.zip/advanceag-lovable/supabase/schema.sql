-- Advance Ag Group / Lovable-ready Supabase schema
create extension if not exists pgcrypto;

create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  category text not null,
  title text not null,
  excerpt text not null,
  body jsonb not null default '[]'::jsonb,
  translations jsonb not null default '{}'::jsonb,
  published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.portfolio (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  title text not null,
  description text not null,
  role text,
  image_url text,
  translations jsonb not null default '{}'::jsonb,
  published boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.inquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  organization text,
  type text,
  message text not null,
  language text not null default 'en',
  status text not null default 'new',
  created_at timestamptz not null default now()
);

alter table public.news enable row level security;
alter table public.portfolio enable row level security;
alter table public.inquiries enable row level security;

create policy "Public can read published news" on public.news for select using (published = true);
create policy "Public can read published portfolio" on public.portfolio for select using (published = true);
create policy "Public can submit inquiries" on public.inquiries for insert with check (true);

-- Keep write/update/delete access to news, portfolio, and inquiry review inside authenticated admin tooling.
-- Lovable can add an admin role policy after authentication is configured.

insert into public.news (slug,category,title,excerpt,body,published,published_at)
values
('from-the-farm-to-the-system','Perspective','From the Farm to the System','Why solving agriculture''s hardest problems requires looking beyond a single technology or point in the supply chain.', '["Advance Ag began with a technology question: how can growers make better use of the tools already around them? That work exposed a broader reality. Farm performance is shaped not only by technology, but by access to inputs, financing, infrastructure, markets, and functioning supply chains.","The Group''s expanded structure reflects that lesson. Advance Ag remains the AgTech business, while Advance Ag Group can build, acquire, invest in, and partner around the wider set of systems that shape agricultural outcomes.","The operating principle remains simple: start with the problem growers actually face, then assemble the right technology, capital, partners, and infrastructure around it."]'::jsonb,true,'2026-08-31'),
('interoperability-before-replacement','AgTech','Interoperability Before Replacement','A practical case for helping agricultural technologies work together instead of asking growers to rebuild their operations around one vendor.', '["Agricultural operations often contain equipment and software from multiple manufacturers. Replacing everything to adopt a single ecosystem can be expensive and unnecessary.","Advance Ag''s technology thesis is built around interoperability: connect useful tools, applications, sensors, and equipment so growers can improve visibility and control without abandoning investments that still work."]'::jsonb,true,'2026-08-18'),
('supply-chain-is-farm-infrastructure','Agrifood Systems','The Supply Chain Is Farm Infrastructure','Production does not create value by itself. Storage, processing, movement, buyers, and market access determine whether harvest becomes opportunity.', '["A productive farm can still struggle when the systems around it are weak. The ability to move a crop, preserve quality, reach buyers, and receive fair value is part of the agricultural operating environment.","That is why Advance Ag Group treats supply chains and market access as part of the architecture behind agriculture—not as an afterthought once production is complete."]'::jsonb,true,'2026-07-29')
on conflict (slug) do nothing;


-- Multilingual content model
-- `translations` stores locale-specific overrides while the base English fields remain the canonical fallback.
-- Example news translations payload:
-- {
--   "es-MX": {"category":"Perspectiva","title":"...","excerpt":"...","body":["..."]},
--   "ar": {"category":"رؤية","title":"...","excerpt":"...","body":["..."]}
-- }
-- Supported locale keys: en, es-MX, pt, nl, de, pl, uk, ru, fr, pcm, ar, sw.

-- Safe migration statements when upgrading an already-created database.
alter table if exists public.news add column if not exists translations jsonb not null default '{}'::jsonb;
alter table if exists public.portfolio add column if not exists translations jsonb not null default '{}'::jsonb;
alter table if exists public.inquiries add column if not exists language text not null default 'en';

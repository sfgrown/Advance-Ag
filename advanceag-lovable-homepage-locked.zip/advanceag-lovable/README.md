# Advance Ag Group — Lovable-ready website

This package is the polished second design pass of the approved Advance Ag Group website direction. It preserves the dark agricultural systems aesthetic, current logo treatment, farmer-first messaging, Group/Advance Ag hierarchy, and adds a functioning news system, portfolio content, inquiry capture, responsive UI, motion, hover states, accessibility improvements, and production-ready backend options.

## Architecture
- `client/` — React + Vite frontend
- `server/` — Express fallback API for local/self-hosted deployment
- `supabase/schema.sql` — preferred Lovable/Supabase production backend
- `.env.example` — environment variables

## Run locally
1. `npm install`
2. `npm run install:all`
3. `npm run dev`
4. Open the Vite URL shown in the terminal.

## Build
`npm run build`

## Lovable handoff
Upload/import the project files into Lovable. Connect Supabase and run `supabase/schema.sql`. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in project environment settings. The frontend automatically prefers Supabase and falls back to `/api` when Supabase is not configured.

## Production notes
- Portfolio photography included in this package is illustrative imagery extracted from the approved visual direction. Replace it with verified project/company photography before presenting a card as a completed investment or project.
- No fabricated investment amounts, customers, metrics, integrations, or portfolio companies are included.
- Replace placeholder social links with verified Advance Ag Group profiles.
- Add authenticated admin policies before allowing CMS writes from a web dashboard.
- For production contact handling, route inquiry events to CRM/email automation in addition to Supabase storage.

## Design pass improvements
- Barlow Condensed display type preserves the approved strong agricultural/industrial voice without turning the site into generic SaaS.
- Libre Baskerville adds editorial/institutional contrast in story and systems sections.
- Inter handles body and UI text for legibility.
- Intersection-reveal motion with `prefers-reduced-motion` support.
- Higher-quality card imagery, hover elevation, image motion, active navigation states, focus states, loading/submission states, 404 route, and responsive mobile navigation.
- Copy tightened around a farmer-shaped systems architecture: the farmer remains central; technology, capital, infrastructure, markets, resources, and institutions are the systems shaped around them.

## Multilingual website
The navigation includes a production-style language picker with these locales: English, Mexican Spanish, Portuguese, Dutch, German, Polish, Ukrainian, Russian, French, Nigerian Pidgin, Arabic, and Swahili.

Static website copy is localized in `client/src/locales.js`. The visitor's choice persists in `localStorage`, browser language is used on first visit when supported, and Arabic automatically enables RTL layout. News and portfolio data support a `translations` JSONB object in Supabase and fall back to English if an editor has not yet supplied a locale. Partnership inquiries record the active locale.

“Nigerian” is not one language. This implementation uses **Nigerian Pidgin (`pcm`)** as the requested Nigeria-wide option. If the intended audience calls for Hausa, Yoruba, Igbo, or another Nigerian language, add them as separate locales rather than labeling a single option “Nigerian.”

## Deep-link content added
The homepage calls-to-action now route to dedicated detail pages rather than generic anchors:
- `/group`
- `/partner`
- `/our-story`
- `/portfolio`
- `/approach/build-operate`
- `/approach/acquire-invest`
- `/approach/partner-advance`
- `/insights/agtech-solutions`
- `/insights/agricultural-innovation`
- `/insights/resource-water-systems`
- `/insights/supply-chain-infrastructure`
- `/insights/strategic-partnerships`

The five Selected Work cards are fully clickable and keyboard accessible. Long-form editorial copy is maintained in `client/src/contentPages.js` so it can be reviewed, translated, or moved to a CMS without rewriting the React view layer.
